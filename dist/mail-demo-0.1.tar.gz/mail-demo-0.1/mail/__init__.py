from mailDemo.mail.handler import send_mail

__all__ = ['send_mail']
